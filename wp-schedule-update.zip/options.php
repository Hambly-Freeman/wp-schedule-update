<?php
class WP_SU_ScheduleUpdate_Options {
  /**
   * Holds all the options
   *
   * @access protected
   *
   * @var array
   */
  protected static $_wp_su_publish_options = [];

  /**
   * Registers all needed options via the wordpress settings API
   *
   * @return void
   * @see register_settig, add_settings_section, add_settings_field
   *
   */
  public static function init() {
    register_setting('wp_su_schedule_update', 'tsu_options');

    add_settings_section(
      'tsu_section',
      '',
      'intval',
      'tsu'
    );

    add_settings_field(
      'tsu_field_nodate',
      __('No Date Set', 'wp-su-scheduleupdate-td'),
      [__CLASS__, 'field_nodate_cb'],
      'tsu',
      'tsu_section',
      [
        'label_for' => 'tsu_nodate',
        'class' => 'tsu_row',
      ]
    );

    add_settings_field(
      'tsu_field_visible',
      __('Posts Visible', 'wp-su-scheduleupdate-td'),
      [__CLASS__, 'field_visible_cb'],
      'tsu',
      'tsu_section',
      [
        'label_for' => 'tsu_visible',
        'class' => 'tsu_row',
      ]
    );

    add_settings_field(
      'tsu_field_recursive',
      __('Recursive scheduling', 'wp-su-scheduleupdate-td'),
      [__CLASS__, 'field_recursive_cb'],
      'tsu',
      'tsu_section',
      [
        'label_for' => 'tsu_recursive',
        'class' => 'tsu_row',
      ]
    );
  }

  /**
   * Loads the saved options from the database
   *
   * @return void
   */
  public static function load_options() {
    self::$_wp_su_publish_options = get_option('tsu_options');
  }

  /**
   * Get a option value
   *
   * @param string $optname name of the option.
   *
   * @return mixed Value of the requested option
   */
  public static function get($optname) {
    if (isset(self::$_wp_su_publish_options[$optname])) {
      return self::$_wp_su_publish_options[$optname];
    }

    return null;
  }

  /**
   * Registers the option page within wordpress
   *
   * @return void
   * @see add_options_page
   *
   */
  public static function options_page() {
    // add top level menu page.
    add_options_page(
      WP_Schedule_Update::$publish_label,
      WP_Schedule_Update::$publish_label,
      'manage_options',
      'tsu',
      [__CLASS__, 'options_page_html']
    );
  }

  /**
   * Renders the settings field for `nodate`
   *
   * @param array $args array of arguments, passed by do_settings_fields.
   *
   * @return void
   */
  public static function field_nodate_cb($args) {
    $options = get_option('tsu_options');
    ?>
    <select id="<?= esc_attr($args['label_for']); ?>"
            name="tsu_options[<?= esc_attr($args['label_for']); ?>]"
    >
      <option value="publish" <?= isset($options[$args['label_for']]) ? (selected($options[$args['label_for']], 'publish', false)) : (''); ?>>
        <?= esc_html(__('Publish right away', 'wp-su-scheduleupdate-td')); ?>
      </option>
      <option value="nothing" <?= isset($options[$args['label_for']]) ? (selected($options[$args['label_for']], 'nothing', false)) : (''); ?>>
        <?= esc_html(__('Don\'t publish', 'wp-su-scheduleupdate-td')); ?>
      </option>
    </select>
    <p class="description">
      <?= esc_html(__('What should happen to a post if it is saved with no date set?', 'wp-su-scheduleupdate-td')); ?>
    </p>

    <?php
  }

  /**
   * Renders the settings field for `visible`
   *
   * @param array $args array of arguments, passed by do_settings_fields.
   *
   * @return void
   */
  public static function field_visible_cb($args) {
    $options = get_option('tsu_options');

    $checked = '';
    if (isset($options[$args['label_for']])) {
      $checked = 'checked="checked"';
    }
    ?>
    <label for="<?= esc_attr($args['label_for']); ?>">
      <input id="<?= esc_attr($args['label_for']); ?>"
             type="checkbox"
             name="tsu_options[<?= esc_attr($args['label_for']); ?>]"
        <?= $checked ?>
      >
      <?= esc_html(__('Scheduled posts are visible for anonymous users in the frontend', 'wp-su-scheduleupdate-td')); ?>
    </label>
    <?php
  }

  /**
   * Renders the settings field for `recursive`
   *
   * @param array $args array of arguments, passed by do_settings_fields.
   *
   * @return void
   */
  public static function field_recursive_cb($args) {
    $options = get_option('tsu_options');

    $checked = '';
    if (isset($options[$args['label_for']])) {
      $checked = 'checked="checked"';
    }
    ?>
    <label for="<?= esc_attr($args['label_for']); ?>">
      <input id="<?= esc_attr($args['label_for']); ?>"
             type="checkbox"
             name="tsu_options[<?= esc_attr($args['label_for']); ?>]"
        <?= $checked; ?>
      >
      <?= esc_html(__('Allow recursive scheduling', 'wp-su-scheduleupdate-td')); ?>
    </label>
    <?php
  }

  /**
   * Renders the options page html
   *
   * @return void
   */
  public static function options_page_html() {
    // check user capabilities.
    if (!current_user_can('manage_options')) {
      return;
    }

    // show error/update messages.
    settings_errors('tsu_messages');
    ?>
    <div class="wrap">
      <h1><?= esc_html(get_admin_page_title()); ?></h1>
      <form action="options.php" method="post">
        <?php settings_fields('wp_su_schedule_update'); ?>

        <?php do_settings_sections('tsu'); ?>

        <?php submit_button(); ?>
      </form>
    </div>
    <?php
  }
}

add_action('admin_init', ['WP_SU_ScheduleUpdate_Options', 'init']);
add_action('admin_menu', ['WP_SU_ScheduleUpdate_Options', 'options_page']);
// since this file gets included inside a `init` callback we can just call this function straight out.
WP_SU_ScheduleUpdate_Options::load_options();
